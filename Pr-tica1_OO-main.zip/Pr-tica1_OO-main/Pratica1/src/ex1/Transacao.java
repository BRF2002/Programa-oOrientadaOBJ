package ex1;

public class Transacao {

	   private String DtaTransacao;
	   private byte TypeTransacao;
	   private double Valor;
	   private byte FormPag;
}
