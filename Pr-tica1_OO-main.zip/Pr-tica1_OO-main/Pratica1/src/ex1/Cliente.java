package ex1;

public class Cliente {

    private String Nome; 
    private String Rg; 
    private String Cpf; 
    private String Cnpj ;
    private boolean Tipocliente; 
}
