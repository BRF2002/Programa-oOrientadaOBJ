package ex1;

public class Carro {

	  private String Carro;
	  private String fabricante; 
	  private String cor; 
	  private double precovenda;
	  private int anoCar; 
}
