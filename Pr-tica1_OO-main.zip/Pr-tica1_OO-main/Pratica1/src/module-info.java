module Pratica1 {
}